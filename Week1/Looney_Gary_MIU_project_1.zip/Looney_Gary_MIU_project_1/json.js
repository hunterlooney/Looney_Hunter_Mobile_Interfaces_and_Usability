//Gary W. Hunter Looney
//Project 1
//Add Character JSON Java
//Term 1305




var json = {
	"character1": {
		"name": ["Name: ", "Bob McTest"],
		"glasses": ["Glasses: ", "Yes"],
		"sex": ["Sex: ", "Male"],
		"birthdate": ["Birthdate: ", "2010-02-05"],
		"race": ["Race: ", "Reptilian"],
		"height": ["Height: ", "7"]
	},
	"character2": {
		"name": ["Name: ", "Shelly McTest"],
		"glasses": ["Glasses: ", "Yes"],
		"sex": ["Sex: ", "Female"],
		"birthdate": ["Birthdate: ", "2010-02-05"],
		"race": ["Race: ", "Reptilian"],
		"height": ["Height: ", "7"]
	},
	"character3": {
		"name": ["Name: ", "George McTest"],
		"glasses": ["Glasses: ", "Yes"],
		"sex": ["Sex: ", "Male"],
		"birthdate": ["Birthdate: ", "2010-02-05"],
		"race": ["Race: ", "Reptilian"],
		"height": ["Height: ", "7"]
	},
	"character4": {
		"name": ["Name: ", "Ann McTest"],
		"glasses": ["Glasses: ", "Yes"],
		"sex": ["Sex: ", "Female"],
		"birthdate": ["Birthdate: ", "2010-02-05"],
		"race": ["Race: ", "Reptilian"],
		"height": ["Height: ", "7"]
	},
	"character5": {
		"name": ["Name: ", "Jorge McTest"],
		"glasses": ["Glasses: ", "Yes"],
		"sex": ["Sex: ", "Male"],
		"birthdate": ["Birthdate: ", "2010-02-05"],
		"race": ["Race: ", "Reptilian"],
		"height": ["Height: ", "7"]
	},
	"character6": {
		"name": ["Name: ", "Leah McTest"],
		"glasses": ["Glasses: ", "Yes"],
		"sex": ["Sex: ", "Female"],
		"birthdate": ["Birthdate: ", "2010-02-05"],
		"race": ["Race: ", "Reptilian"],
		"height": ["Height: ", "7"]
	},
	"character7": {
		"name": ["Name: ", "James McTest"],
		"glasses": ["Glasses: ", "Yes"],
		"sex": ["Sex: ", "Male"],
		"birthdate": ["Birthdate: ", "2010-02-05"],
		"race": ["Race: ", "Feline"],
		"height": ["Height: ", "6"]
	},
	"character8": {
		"name": ["Name: ", "Kristen McTest"],
		"glasses": ["Glasses: ", "Yes"],
		"sex": ["Sex: ", "Female"],
		"birthdate": ["Birthdate: ", "2010-02-05"],
		"race": ["Race: ", "Feline"],
		"height": ["Height: ", "6"]
	},
	"character9": {
		"name": ["Name: ", "Tanner McTest"],
		"glasses": ["Glasses: ", "Yes"],
		"sex": ["Sex: ", "Male"],
		"birthdate": ["Birthdate: ", "2010-02-05"],
		"race": ["Race: ", "Feline"],
		"height": ["Height: ", "6"]
	},
	"character10": {
		"name": ["Name: ", "Kylee McTest"],
		"glasses": ["Glasses: ", "Yes"],
		"sex": ["Sex: ", "Female"],
		"birthdate": ["Birthdate: ", "2010-02-05"],
		"race": ["Race: ", "Feline"],
		"height": ["Height: ", "6"]
	},
	"character11": {
		"name": ["Name: ", "Mike McTest"],
		"glasses": ["Glasses: ", "No"],
		"sex": ["Sex: ", "Male"],
		"birthdate": ["Birthdate: ", "2010-02-05"],
		"race": ["Race: ", "Feline"],
		"height": ["Height: ", "6"]
	},
	"character12": {
		"name": ["Name: ", "Hallie McTest"],
		"glasses": ["Glasses: ", "No"],
		"sex": ["Sex: ", "Female"],
		"birthdate": ["Birthdate: ", "2010-02-05"],
		"race": ["Race: ", "Feline"],
		"height": ["Height: ", "6"]
	},
	"character13": {
		"name": ["Name: ", "Brad McTest"],
		"glasses": ["Glasses: ", "No"],
		"sex": ["Sex: ", "Male"],
		"birthdate": ["Birthdate: ", "2010-02-05"],
		"race": ["Race: ", "Feline"],
		"height": ["Height: ", "6"]
	},
	"character14": {
		"name": ["Name: ", "Katrina McTest"],
		"glasses": ["Glasses: ", "No"],
		"sex": ["Sex: ", "Female"],
		"birthdate": ["Birthdate: ", "2010-02-05"],
		"race": ["Race: ", "Feline"],
		"height": ["Height: ", "6"]
	},
	"character15": {
		"name": ["Name: ", "Gary McTest"],
		"glasses": ["Glasses: ", "No"],
		"sex": ["Sex: ", "Male"],
		"birthdate": ["Birthdate: ", "2010-02-05"],
		"race": ["Race: ", "Elf"],
		"height": ["Height: ", "5"]
	},
	"character16": {
		"name": ["Name: ", "Ashley McTest"],
		"glasses": ["Glasses: ", "No"],
		"sex": ["Sex: ", "Female"],
		"birthdate": ["Birthdate: ", "2010-02-05"],
		"race": ["Race: ", "Elf"],
		"height": ["Height: ", "5"]
	},
	"character17": {
		"name": ["Name: ", "Scotty McTest"],
		"glasses": ["Glasses: ", "No"],
		"sex": ["Sex: ", "Male"],
		"birthdate": ["Birthdate: ", "2010-02-05"],
		"race": ["Race: ", "Elf"],
		"height": ["Height: ", "5"]
	},
	"character18": {
		"name": ["Name: ", "Betty McTest"],
		"glasses": ["Glasses: ", "No"],
		"sex": ["Sex: ", "Female"],
		"birthdate": ["Birthdate: ", "2010-02-05"],
		"race": ["Race: ", "Elf"],
		"height": ["Height: ", "5"]
	},
	"character19": {
		"name": ["Name: ", "John McTest"],
		"glasses": ["Glasses: ", "No"],
		"sex": ["Sex: ", "Male"],
		"birthdate": ["Birthdate: ", "2010-02-05"],
		"race": ["Race: ", "Elf"],
		"height": ["Height: ", "5"]
	},
	"character20": {
		"name": ["Name: ", "Cheryl McTest"],
		"glasses": ["Glasses: ", "No"],
		"sex": ["Sex: ", "Female"],
		"birthdate": ["Birthdate: ", "2010-02-05"],
		"race": ["Race: ", "Elf"],
		"height": ["Height: ", "5"]
	}

};